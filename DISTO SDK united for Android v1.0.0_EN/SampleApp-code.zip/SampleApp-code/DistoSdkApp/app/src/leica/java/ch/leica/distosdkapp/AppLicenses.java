package ch.leica.distosdkapp;

import java.util.ArrayList;

public class AppLicenses {
	public ArrayList<String> keys = new ArrayList<>();

	public AppLicenses(){
		String key1 = "1Xj1z6thybdW/O+Jc6XG2ExVzYuY3GF4h+";
		keys.add(key1);

	}
}

